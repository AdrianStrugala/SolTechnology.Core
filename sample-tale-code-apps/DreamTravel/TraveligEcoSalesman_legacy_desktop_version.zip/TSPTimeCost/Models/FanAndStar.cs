﻿namespace TSPTimeCost.Models
{
    class FanAndStar
    {
        public FanAndStar(int fan, int star)
        {
            Fan = fan;
            Star = star;
        }

        public int Fan { get; set; }
        public int Star { get; set; }
    }

}
