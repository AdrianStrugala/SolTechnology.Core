﻿namespace TSPTimeCost.Models {
    class VertexAndProbability {
        public int Vertex { get; set; }
        public double Probability { get; set; }
    }

}
